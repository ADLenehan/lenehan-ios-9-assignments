//
//  SplitterViewController.swift
//  Homework2
//
//  Created by Andrew Lenehan on 7/5/16.
//  Copyright © 2016 Andrew Lenehan. All rights reserved.
//

import UIKit

class SplitterViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
}
    
    @IBOutlet weak var amountTextField: UITextField!
    @IBOutlet weak var tipTextField: UITextField!
    @IBOutlet weak var numSplitsTextField: UITextField!
    @IBOutlet weak var totalLabel: UILabel!
    
    @IBAction func splitBarButton(sender: UIBarButtonItem) {
        if
            let amount = Int(amountTextField.text!),
            let tip = Int(tipTextField.text!),
            let numSplits = Int(numSplitsTextField.text!)
        {
            totalLabel.text = String(amount * tip / 100 / numSplits)
            
        }
    }

    
    
    
}
