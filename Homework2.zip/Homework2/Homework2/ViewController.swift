//
//  ViewController.swift
//  Homework2
//
//  Created by Andrew Lenehan on 7/5/16.
//  Copyright © 2016 Andrew Lenehan. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBOutlet weak var yearTextField: UITextField!
    @IBOutlet weak var messageLabel: UILabel!
    @IBAction func verifyButton(sender: AnyObject) {
        if
            let yearBorn = Int(yearTextField.text!){
            if 2016 - yearBorn < 16 {
                messageLabel.text = "You're a baby and don't need a phone"
            } else if 2016 - yearBorn < 18 {
                messageLabel.text = "You can drive"
            } else if 2016 - yearBorn < 21 {
                messageLabel.text = "You can drive and vote"
            } else {
                messageLabel.text = "You can drink, vote and drive"
            }
            
        }
    }



}

