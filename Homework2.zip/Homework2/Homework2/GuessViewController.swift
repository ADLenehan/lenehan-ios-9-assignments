//
//  GuessViewController.swift
//  Homework2
//
//  Created by Andrew Lenehan on 7/5/16.
//  Copyright © 2016 Andrew Lenehan. All rights reserved.
//


import UIKit

class GuessViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
}
    @IBOutlet weak var guessTextField: UITextField!
    @IBOutlet weak var responseLabel: UILabel!
    let random = Int(arc4random() % 10)
    @IBAction func guessButton(sender: AnyObject) {
        if
            let guess = Int(guessTextField.text!) {
                print(random)
            if guess == random {
                responseLabel.text = "YOU GOT IT"
            } else {
                responseLabel.text = "WRONG"
            }
        }
    }

}