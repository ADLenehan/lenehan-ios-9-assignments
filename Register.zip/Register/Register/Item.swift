//
//  Item.swift
//  Register
//
//  Created by Andrew Lenehan on 8/3/16.
//  Copyright © 2016 Andrew Lenehan. All rights reserved.
//

import Foundation

class Item {
    
    let title: String
    let price: Double
    
    init(title: String, price: Double) {
        self.title = title
        self.price = price
    }
}
