//
//  CheckoutViewController.swift
//  Register
//
//  Created by Andrew Lenehan on 8/6/16.
//  Copyright © 2016 Andrew Lenehan. All rights reserved.
//

import UIKit

class CheckoutViewController: UIViewController {
    
    var checkoutList:[Item]?
    var totalPrice:Double?
    @IBOutlet weak var numItemsLabel: UILabel!
    @IBOutlet weak var totalLabel: UILabel!
    @IBOutlet weak var inputCashField: UITextField!
    @IBOutlet weak var doubleWarningLabel: UILabel!
    
    @IBAction func checkoutButtonAction(sender: AnyObject) {
        guard
            let text = inputCashField.text,
            let doubleCash = Double(text) else
        {
            doubleWarningLabel.text = "Enter valid cash amount (2 decimals)"
            return
        }
        
        if
            let totalPrice = totalPrice {
            let finalChange = doubleCash - totalPrice
        if finalChange < 0 {
            doubleWarningLabel.text = "That's not enough money!!"
        } else {
            if let changeViewController = storyboard?.instantiateViewControllerWithIdentifier("ChangeViewController") as? ChangeViewController {
            changeViewController.changeOwed = finalChange
            showViewController(changeViewController, sender: self)
            }
        }
    }
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        
        if let checkoutList = checkoutList,
            let totalPrice = totalPrice {
            numItemsLabel.text = String(checkoutList.count)
            totalLabel.text = String(totalPrice)
        } else {
            numItemsLabel.text = "0"
            totalLabel.text = "0.00"
        }
        
    }


}
