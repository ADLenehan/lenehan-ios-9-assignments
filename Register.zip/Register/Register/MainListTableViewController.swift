//
//  ViewController.swift
//  Register
//
//  Created by Andrew Lenehan on 8/3/16.
//  Copyright © 2016 Andrew Lenehan. All rights reserved.
//

import UIKit

class MainListTableViewController: UITableViewController, AddViewControllerDelegate {
    
    private var itemList = [Item]()
    var totalPrice = 0.0
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "addsegueidentifier" {
            if
                let addNavigationController = segue.destinationViewController as? UINavigationController,
                let addViewController = addNavigationController.topViewController as? AddViewController {
                    addViewController.delegate = self
                }
            }
        if segue.identifier == "checkoutsegueidentifier" {
            if let checkoutViewController = segue.destinationViewController as? CheckoutViewController {
                checkoutViewController.checkoutList = itemList
                checkoutViewController.totalPrice = totalPrice
            }
        }
    }
    

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return itemList.count
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCellWithIdentifier("maincellidentifier", forIndexPath: indexPath)
        
        let item = itemList[indexPath.row]
        cell.textLabel?.text = item.title
        cell.detailTextLabel?.text = String(item.price)
        return cell
    }
        
    func userDidAddItem(item: Item) {
        totalPrice += item.price
        itemList.append(item)
        tableView.reloadData()
    }
}




