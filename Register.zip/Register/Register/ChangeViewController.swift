//
//  ChangeViewController.swift
//  Register
//
//  Created by Andrew Lenehan on 8/6/16.
//  Copyright © 2016 Andrew Lenehan. All rights reserved.
//

import UIKit

class ChangeViewController: UIViewController {
    
    var changeOwed:Double = 0.0
    @IBOutlet weak var finalChangeLabel: UILabel!
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        finalChangeLabel.text = String(changeOwed)
    }
    

}
