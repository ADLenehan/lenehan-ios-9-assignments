//
//  AddItemViewController.swift
//  Register
//
//  Created by Andrew Lenehan on 8/7/16.
//  Copyright © 2016 Andrew Lenehan. All rights reserved.
//

import UIKit

protocol AddItemViewControllerDelegate: class {
    func userDidAddNewItem(item: Item)
}

class AddItemViewController: UIViewController {
    weak var itemdelegate: AddItemViewControllerDelegate?
    
    @IBOutlet weak var ItemTextField: UITextField!
    @IBOutlet weak var PriceTextField: UITextField!
    
    @IBAction func DoneButton(sender: AnyObject) {
        guard
            let itemType = ItemTextField.text,
            let priceType = Double(PriceTextField.text!) else
        {
            return
        }
        
        let currentItem2 = Item(title: itemType, price: priceType)
        itemdelegate?.userDidAddNewItem(currentItem2)
        dismissViewControllerAnimated(true, completion: nil)
    }
}
