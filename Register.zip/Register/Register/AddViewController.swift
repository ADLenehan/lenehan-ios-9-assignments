//
//  AddViewController.swift
//  Register
//
//  Created by Andrew Lenehan on 8/3/16.
//  Copyright © 2016 Andrew Lenehan. All rights reserved.
//

import UIKit

protocol AddViewControllerDelegate: class {
    func userDidAddItem(item: Item)
}

class AddViewController: UIViewController, AddItemViewControllerDelegate {
    
    weak var delegate: AddViewControllerDelegate?
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "additemsegueidentifier" {
            if
                let addItemViewController = segue.destinationViewController as? AddItemViewController {
                addItemViewController.itemdelegate = self
            }
        }
    }

    
    @IBAction func item1Button(sender: AnyObject) {
        let currentItem = Item(title:"Apple", price: 0.99)
        delegate?.userDidAddItem(currentItem)
        dismissViewControllerAnimated(true, completion: nil)
    }
    @IBAction func item2Button(sender: AnyObject) {
        let currentItem = Item(title:"Orange", price: 1.99)
        delegate?.userDidAddItem(currentItem)
        dismissViewControllerAnimated(true, completion: nil)
    }
    @IBAction func item3Button(sender: AnyObject) {
        let currentItem = Item(title:"Banana", price: 2.99)
        delegate?.userDidAddItem(currentItem)
        dismissViewControllerAnimated(true, completion: nil)
    }

    @IBAction func cancelButtonAction(sender: AnyObject) {
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    func userDidAddNewItem(item: Item){
        let currentItem = Item(title: item.title, price: item.price)
        delegate?.userDidAddItem(currentItem)
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    
}
