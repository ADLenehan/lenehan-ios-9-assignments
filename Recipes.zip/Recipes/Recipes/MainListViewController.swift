//
//  ViewController.swift
//  Recipes
//
//  Created by Andrew Lenehan on 7/24/16.
//  Copyright © 2016 Andrew Lenehan. All rights reserved.
//

import UIKit

class MainListViewController: UITableViewController {

    private var recipeList = [Recipe(name: "Peanut Butter and Jelly", cookingTime: "2 minutes", description: "Peanut butter and jelly on bread", ingredientList: "Bread, Peanut Butter, Jelly", steps: "Spread both on bread and eat"), Recipe(name: "Grilled Cheese", cookingTime: "2 minutes", description: "Cheese on bread", ingredientList: "Bread, Cheese", steps: "Put cheese on bread and grill")]
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "detailsegueidentifier" {
            if let detailsViewController = segue.destinationViewController as? DetailsViewController {
                if let indexPath = tableView.indexPathForSelectedRow {
                    let currentRecipe = recipeList[indexPath.row]
                    detailsViewController.currentRecipe = currentRecipe
                }
            }
        }
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return recipeList.count
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCellWithIdentifier("maincellidentifier", forIndexPath: indexPath)
        
        let currentRecipe = recipeList[indexPath.row]
        cell.textLabel?.text = currentRecipe.name
        cell.detailTextLabel?.text = currentRecipe.description
        
        return cell
    }
}


