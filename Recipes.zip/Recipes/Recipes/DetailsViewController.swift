//
//  DetailsViewController.swift
//  Recipes
//
//  Created by Andrew Lenehan on 7/24/16.
//  Copyright © 2016 Andrew Lenehan. All rights reserved.
//

import UIKit

class DetailsViewController: UIViewController {
    
    var currentRecipe : Recipe?
    
    @IBOutlet weak var recipeNameLabel: UILabel!

    @IBOutlet weak var recipeDescriptionLabel: UILabel!
    @IBOutlet weak var recipeIngredientsLabel: UILabel!
    @IBOutlet weak var recipeTimeLabel: UILabel!
    
    @IBOutlet weak var recipeStepsLabel: UILabel!

    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        
        if let currentRecipe = currentRecipe {
            recipeNameLabel.text = currentRecipe.name
            recipeDescriptionLabel.text = currentRecipe.description
            recipeIngredientsLabel.text = "Ingredients: " + currentRecipe.ingredientList
            recipeTimeLabel.text = "Time: " + currentRecipe.cookingTime
            recipeStepsLabel.text = "Steps: " + currentRecipe.steps
        }
    }
}

