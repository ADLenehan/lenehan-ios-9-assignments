//
//  Recipe.swift
//  Recipes
//
//  Created by Andrew Lenehan on 7/24/16.
//  Copyright © 2016 Andrew Lenehan. All rights reserved.
//

import Foundation

class Recipe {
    
    var name : String
    var cookingTime : String
    var description: String
    var ingredientList: String
    var steps: String
    
    init (name : String, cookingTime : String, description : String, ingredientList: String, steps: String){
        self.name = name
        self.cookingTime = cookingTime
        self.description = description
        self.ingredientList = ingredientList
        self.steps = steps
    }
}
